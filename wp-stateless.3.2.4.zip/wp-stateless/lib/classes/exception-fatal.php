<?php

namespace wpCloud\StatelessMedia;

class FatalException extends \Exception {
}

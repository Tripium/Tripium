<?php

namespace wpCloud\StatelessMedia;

class UnprocessableException extends \Exception {
}
